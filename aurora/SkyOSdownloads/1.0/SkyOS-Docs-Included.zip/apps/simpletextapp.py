import sys

def main():
    print("Simple Text")
    print("(What did you expect from an app called simpletext?)")
    print("Oh, and by the way... 10 + 20 = " + str(10 + 20) + "! How cool!")
    print("Thanks, scratch_fakemon!")
    sys.exit()

if __name__ == "__main__":
    main()
