import sys

def main():
    print("Hello, World!")
    print("Make an app in the app folder (with the same structure just modified to fit your app code).")
    sys.exit()

if __name__ == "__main__":
    main()
